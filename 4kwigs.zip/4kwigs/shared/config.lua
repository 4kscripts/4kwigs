Config = {}

Config.Framework = 'ESX' -- 'ESX' | 'QB' | 'QBX'
Config.Notification = 'ox_lib' -- 'ox_lib' | 'esx' | 'qb' | 'okok' | 'custom'

Config.Job = {
    name = 'wigs',
    label = 'Wig Crafting',
    grade = 0
}

Config.Minigame = {
    enabled = true, -- Skill check prior to progression
}

Config.wigAppearance = {
    enabled = true, -- Allow female characters to wear wigs
    wigStyles = {
        ['bob_wig'] = { hair = 36, color = 4 },
        ['pixie_wig'] = { hair = 38, color = 4 },
        ['curly_bob_wig'] = { hair = 12, color = 5 },
        ['layered_short_wig'] = { hair = 18, color = 0 },
        ['shoulder_straight_wig'] = { hair = 4, color = 2 },
        ['medium_wavy_wig'] = { hair = 9, color = 2 },
        ['shoulder_curly_wig'] = { hair = 14, color = 6 },
        ['blunt_cut_wig'] = { hair = 17, color = 0 },
        ['long_straight_wig'] = { hair = 3, color = 0 },
        ['long_wavy_wig'] = { hair = 2, color = 3 },
        ['long_curly_wig'] = { hair = 8, color = 7 },
        ['long_layered_wig'] = { hair = 5, color = 2 },
        ['braided_wig'] = { hair = 13, color = 5 },
        ['afro_wig'] = { hair = 15, color = 0 },
        ['dreadlock_wig'] = { hair = 20, color = 0 },
        ['mohawk_wig'] = { hair = 35, color = 4 },
        ['ponytail_wig'] = { hair = 23, color = 1 },
        ['twist_wig'] = { hair = 24, color = 8 }
    }
}

Config.shopPed = {
    enabled = true,
    model = 'a_f_y_business_02',
    coords = vector4(-57.7826, -204.1402, 45.8052, 340.0947),
    scenario = 'WORLD_HUMAN_STAND_MOBILE'
}

Config.blipsMap = {
    wigShop = { enabled = true, coords = vector3(-67.1161, -214.0042, 45.4449), sprite = 197, scale = 0.7, colour = 8, name = "Wig Store" }
}

Config.shopItems = {
    {name = 'hair_fiber', price = 50, label = 'Hair Fiber'},
    {name = 'wig_cap', price = 25, label = 'Wig Cap'},
    {name = 'wig_table', price = 500, label = 'Wig Crafting Table'},
    {name = 'hair_dye', price = 75, label = 'Hair Dye'},
    {name = 'styling_gel', price = 30, label = 'Styling Gel'},
    {name = 'hair_clips', price = 15, label = 'Hair Clips'}
}

Config.wigTypes = {
    { name = "Bob Wig", time = 7, requirements = {{item = "hair_fiber", amount = 2}, {item = "wig_cap", amount = 1}, {item = "hair_clips", amount = 2}}, reward = "bob_wig"},
    { name = "Pixie Wig", time = 5, requirements = {{item = "hair_fiber", amount = 1}, {item = "wig_cap", amount = 1}, {item = "hair_clips", amount = 2}}, reward = "pixie_wig"},
    { name = "Curly Bob Wig", time = 8, requirements = {{item = "hair_fiber", amount = 2}, {item = "wig_cap", amount = 1}, {item = "hair_clips", amount = 2}, {item = "styling_gel", amount = 1}}, reward = "curly_bob_wig"},
    { name = "Straight Hair Bundle", time = 10, requirements = {{item = "hair_fiber", amount = 5}, {item = "hair_clips", amount = 2}}, reward = "straight_bundle"}
}

Config.DeliverySystem = {
    enabled = true,
    vehicleModel = 'boxville7',
    vehicleSpawn = vector4(253.3360, -1493.2014, 29.1417, 226.1033),
    givekeyScript = 'custom', -- 'mk_vehiclekeys' | 'wasabi_carlock' | 'qs-vehiclekeys' | 'cd_garage' | 'qb'
    deliveryLocations = {
        {coords = vector4(-824.4159, -187.4863, 37.6277, 120.99), label = "Bob Mulet"},
        {coords = vector4(130.8206, -1712.0087, 29.2823, 149.74), label = "Herr Kutz Barber"},
        {coords = vector4(-1288.9818, -1117.3472, 6.9852, 60.61), label = "Beach Combover Barber"},
        {coords = vector4(-31.6468, -145.8780, 57.0448, 356.15), label = "Hair on Hawick"}
    },
    peds = { 'a_f_m_downtown_01', 'a_f_m_eastsa_01', 'a_f_m_eastsa_02' }
}

Config.sellWigs = {
    enabled = true,
    command = 'sellwigs',
    bargainTime = 5000,
    rejectRate = 45,
    minSellAmount = 1,
    maxSellAmount = 5,
    requiredCops = 0,
    peds = { 'a_f_m_skidrow_01', 'a_f_m_soucentmc_01', 'g_f_y_ballas_01' }
}

Config.Prices = {
    ['bob_wig'] = {priceMin = 3000, priceMax = 4000, money = 'clean'},
    ['pixie_wig'] = {priceMin = 4500, priceMax = 5500, money = 'clean'},
    ['curly_bob_wig'] = {priceMin = 5500, priceMax = 6500, money = 'clean'},
    ['straight_bundle'] = {priceMin = 7800, priceMax = 8500, money = 'clean'}
}