fx_version 'cerulean'
game 'gta5'

author 'AdminPlus'
description 'Advanced Wig Job, Crafting, Delivery, Selling, and Snatching System'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua',
    'shared/translations.lua'
}

client_scripts {
    'client/client_editable.lua',
    'client/main.lua'
}

server_scripts {
    'server/server_editable.lua',
    'server/main.lua'
}

dependencies {
    'ox_lib'
}