-- STRICT RESOURCE DIRECTORY LOCK MECHANISM
if GetCurrentResourceName() ~= "4kwigs" then
    CreateThread(function()
        while true do
            Wait(5000)
            print("\n^1[FATAL ERROR] 4kwigs script execution halted! The folder name MUST be exactly '4kwigs'. Please rename your resource directory back to '4kwigs'.^7\n")
        end
    end)
    return -- Kills the remainder of the server script initialization loop completely
end

local Framework = nil
local QBCore = nil
local ESX = nil

if Config.Framework == 'QB' or Config.Framework == 'QBX' then
    QBCore = exports['qb-core']:GetCoreObject()
elseif Config.Framework == 'ESX' then
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
end

-- Server Native Wrapper Inventory Mechanics Helper
local function GetPlayerInventoryItem(source, itemName)
    if QBCore then
        local Player = QBCore.Functions.GetPlayer(source)
        local item = Player.Functions.GetItemByName(itemName)
        return item and item.amount or 0
    elseif ESX then
        local xPlayer = ESX.GetPlayerFromId(source)
        local item = xPlayer.getInventoryItem(itemName)
        return item and item.count or 0
    end
    return 0
end

local function RemoveInventoryItem(source, itemName, count)
    if QBCore then
        local Player = QBCore.Functions.GetPlayer(source)
        Player.Functions.RemoveItem(itemName, count)
    elseif ESX then
        local xPlayer = ESX.GetPlayerFromId(source)
        xPlayer.removeInventoryItem(itemName, count)
    end
end

local function AddInventoryItem(source, itemName, count)
    if QBCore then
        local Player = QBCore.Functions.GetPlayer(source)
        Player.Functions.AddItem(itemName, count)
    elseif ESX then
        local xPlayer = ESX.GetPlayerFromId(source)
        xPlayer.addInventoryItem(itemName, count)
    end
end

-- Core Interaction Processor Handlers with Dynamic Quantity Multiplication Engine
RegisterNetEvent('4kwigs:server:processPurchase', function(data, quantity)
    local src = source
    local quantity = math.floor(tonumber(quantity or 1))
    if quantity <= 0 then return end
    
    local totalPrice = data.price * quantity
    local cash = 0

    if QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        cash = Player.PlayerData.money['cash']
        if cash >= totalPrice then
            Player.Functions.RemoveMoney('cash', totalPrice)
            Player.Functions.AddItem(data.item, quantity)
            Notification(src, { description = string.format(Config.Strings.shop_purchase_success, quantity, data.label), type = 'success' })
        else
            Notification(src, { description = Config.Strings.shop_insufficient_funds, type = 'error' })
        end
    elseif ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        cash = xPlayer.getMoney()
        if cash >= totalPrice then
            xPlayer.removeMoney(totalPrice)
            xPlayer.addInventoryItem(data.item, quantity)
            Notification(src, { description = string.format(Config.Strings.shop_purchase_success, quantity, data.label), type = 'success' })
        else
            Notification(src, { description = Config.Strings.shop_insufficient_funds, type = 'error' })
        end
    end
end)

-- Validation & Processing Routing Engine supporting Dynamic Batched Multipliers
RegisterNetEvent('4kwigs:server:attemptCraft', function(craftData, quantity)
    local src = source
    local quantity = math.floor(tonumber(quantity or 1))
    if quantity <= 0 then return end
    local missing = false

    for _, req in ipairs(craftData.requirements) do
        local requiredTotal = req.amount * quantity
        if GetPlayerInventoryItem(src, req.item) < requiredTotal then
            missing = true
            break
        end
    end

    if missing then
        Notification(src, { description = Config.Strings.craft_missing_materials, type = 'error' })
    else
        TriggerClientEvent('4kwigs:client:startCraftingProg', src, craftData, quantity)
    end
end)

RegisterNetEvent('4kwigs:server:giveCraftReward', function(craftData, quantity)
    local src = source
    local quantity = math.floor(tonumber(quantity or 1))
    if quantity <= 0 then return end

    for _, req in ipairs(craftData.requirements) do
        local requiredTotal = req.amount * quantity
        RemoveInventoryItem(src, req.item, requiredTotal)
    end

    AddInventoryItem(src, craftData.reward, quantity)
    Notification(src, { description = string.format("Successfully crafted %dx %s", quantity, craftData.name), type = 'success' })
end)

-- Pocket Vendor Distribution Dynamic Modules 
RegisterNetEvent('4kwigs:server:initiatePocketSell', function(targetNetId)
    local src = source
    local targetedWig = nil

    for wigItem, _ in pairs(Config.Prices) do
        if GetPlayerInventoryItem(src, wigItem) > 0 then
            targetedWig = wigItem
            break
        end
    end

    if not targetedWig then
        Notification(src, { description = Config.Strings.sell_no_wigs, type = 'error' })
        return
    end

    local prc = Config.Prices[targetedWig]
    local reward = math.random(prc.priceMin, prc.priceMax)

    TriggerClientEvent('4kwigs:client:approachPlayer', src, targetedWig, reward, targetNetId)
end)

-- Dynamic Income Distribution Logic Engine
RegisterNetEvent('4kwigs:server:finalizePocketSale', function(targetWig, reward)
    local src = source
    if GetPlayerInventoryItem(src, targetWig) > 0 then
        RemoveInventoryItem(src, targetWig, 1)
        
        local isDirty = Config.Prices[targetWig].money == 'dirty'
        
        if QBCore then
            local Player = QBCore.Functions.GetPlayer(src)
            if isDirty then
                if Player.Functions.AddItem("markedbills", 1, false, {worth = reward}) then
                    TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Functions.GetItemByName("markedbills"), "add")
                else
                    Player.Functions.AddMoney('cash', reward, "wig-pocket-sale-dirty-fallback")
                end
            else
                Player.Functions.AddMoney('cash', reward, "wig-pocket-sale-clean")
            end
        elseif ESX then
            local xPlayer = ESX.GetPlayerFromId(src)
            if isDirty then
                if xPlayer.getAccount('black_money') then
                    xPlayer.addAccountMoney('black_money', reward)
                else
                    xPlayer.addMoney(reward)
                end
            else
                xPlayer.addMoney(reward)
            end
        end
        
        Notification(src, { description = string.format(Config.Strings.sell_success, 1, targetWig, reward), type = 'success' })
    end
end)

-- Crafting Table Placement Core Authorization Handler
RegisterNetEvent('4kwigs:server:confirmPlacement', function(coords, heading)
    local src = source

    if GetPlayerInventoryItem(src, "wig_table") > 0 then
        local modelHash = `prop_ven_market_table1`
        local tableObj = nil

        if Config.Framework == 'ESX' and ESX and ESX.OneSync and ESX.OneSync.SpawnObject then
            tableObj = ESX.OneSync.SpawnObject(modelHash, vector3(coords.x, coords.y, coords.z), heading)
        else
            tableObj = CreateObject(modelHash, coords.x, coords.y, coords.z, true, true, false)
            if DoesEntityExist(tableObj) then
                SetEntityHeading(tableObj, heading)
            end
        end
        
        local timeout = 0
        while not DoesEntityExist(tableObj) and timeout < 50 do
            Wait(10)
            timeout = timeout + 1
        end

        if DoesEntityExist(tableObj) then
            RemoveInventoryItem(src, "wig_table", 1)
            FreezeEntityPosition(tableObj, true)
            Notification(src, { description = "Crafting table placed successfully!", type = 'success' })
        else
            TriggerClientEvent('4kwigs:client:spawnLocalTableFallback', src, coords, heading)
            RemoveInventoryItem(src, "wig_table", 1)
            Notification(src, { description = "Crafting table deployed via safe fallback layer.", type = 'success' })
        end
    else
        Notification(src, { description = "You don't have a crafting table to place.", type = 'error' })
    end
end)

-- Pickup Server Routine Logic
RegisterNetEvent('4kwigs:server:pickupTable', function(netId)
    local src = source
    local entity = NetworkGetEntityFromNetworkId(netId)

    if DoesEntityExist(entity) then
        DeleteEntity(entity)
        AddInventoryItem(src, "wig_table", 1)
        Notification(src, { description = "You packed up the crafting table and returned it to your inventory.", type = 'success' })
    else
        Notification(src, { description = "Could not locate the table entity securely.", type = 'error' })
    end
end)

-- Standard Usable Items Registrations Deployment Setup
CreateThread(function()
    -- Register Wearable Wigs
    for item, _ in pairs(Config.wigAppearance.wigStyles) do
        if QBCore then
            QBCore.Functions.CreateUseableItem(item, function(source, itemData)
                TriggerClientEvent('4kwigs:client:applyHairstyle', source, itemData.name)
            end)
        elseif ESX then
            ESX.RegisterUsableItem(item, function(source)
                TriggerClientEvent('4kwigs:client:applyHairstyle', source, item)
            end)
        end
    end

    -- Register Placeable Crafting Table Item Callback
    if QBCore then
        QBCore.Functions.CreateUseableItem("wig_table", function(source, itemData)
            TriggerClientEvent('4kwigs:client:placeTable', source)
        end)
    elseif ESX then
        ESX.RegisterUsableItem("wig_table", function(source)
            TriggerClientEvent('4kwigs:client:placeTable', source)
        end)
    end
end)