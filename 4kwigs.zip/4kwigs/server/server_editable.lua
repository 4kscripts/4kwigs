function Notification(playerId, data)
    if Config.Notification == 'ox_lib' then
        TriggerClientEvent('ox_lib:notify', playerId, {
            title = data.title or Config.Strings.notification_title,
            description = data.description,
            type = data.type or 'info',
            duration = data.duration or 5000
        })
    elseif Config.Notification == 'qb' then
        TriggerClientEvent('QBCore:Notify', playerId, data.description, data.type, data.duration)
    elseif Config.Notification == 'esx' then
        TriggerClientEvent('esx:showNotification', playerId, data.description, data.type, data.duration)
    end
end