-- STRICT RESOURCE DIRECTORY LOCK MECHANISM
if GetCurrentResourceName() ~= "4kwigs" then
    CreateThread(function()
        while true do
            Wait(5000)
            print("^1[ERROR] Core Initialization Failed! This resource folder MUST be named exactly '4kwigs' to operate properly.^7")
            lib.notify({
                title = 'System Error',
                description = 'Fatal: Improper folder naming detected. Resource directory must be explicitly called 4kwigs.',
                type = 'error',
                duration = 10000
            })
        end
    end)
    return 
end

local currentDelivery = nil
local deliveryVehicle = nil
local deliveryBlip = nil
local deliveryPed = nil
local isHoldingTable = false
local spawnedTable = nil
local holdingBag = nil 

-- State Trackers for the Automatic Ped Spawner Engine
local isSellingActive = false
local currentCustomerPed = nil

-- Array of randomized base-game civilian models to pull from for automatic spawning
local randomPedModels = {
    `a_f_m_beachtourist_01`,
    `a_f_m_bodybuild_01`,
    `a_f_m_business_02`,
    `a_f_m_downtown_01`,
    `a_f_m_eastsa_01`,
    `a_f_m_fatbla_01`,
    `a_f_m_skidrow_01`,
    `a_f_m_soucent_01`,
    `a_f_m_soucent_02`,
    `a_f_m_tourist_01`,
    `a_f_y_beach_01`,
    `a_f_y_business_01`,
    `a_f_y_business_02`,
    `a_f_y_business_03`,
    `a_f_y_business_04`,
    `a_f_y_eastsa_01`,
    `a_f_y_eastsa_02`,
    `a_f_y_epsilon_01`,
    `a_f_y_fitness_01`,
    `a_f_y_fitness_02`,
    `a_f_y_hippie_01`
}

-- Setup Shop Ped & Blip
CreateThread(function()
    if Config.shopPed.enabled then
        local model = GetHashKey(Config.shopPed.model)
        RequestModel(model)
        while not HasModelLoaded(model) do Wait(10) end
        
        local ped = CreatePed(4, model, Config.shopPed.coords.x, Config.shopPed.coords.y, Config.shopPed.coords.z - 1.0, Config.shopPed.coords.w, false, true)
        
        SetEntityAsMissionEntity(ped, true, true) 
        FreezeEntityPosition(ped, true)
        SetEntityInvincible(ped, true)
        SetBlockingOfNonTemporaryEvents(ped, true)
        
        if Config.shopPed.scenario ~= '' then
            TaskStartScenarioInPlace(ped, Config.shopPed.scenario, 0, true)
        end
        
        if Config.blipsMap.wigShop.enabled then
            local blip = AddBlipForCoord(Config.blipsMap.wigShop.coords)
            SetBlipSprite(blip, Config.blipsMap.wigShop.sprite)
            SetBlipDisplay(blip, 4)
            SetBlipScale(blip, Config.blipsMap.wigShop.scale)
            SetBlipColour(blip, Config.blipsMap.wigShop.colour) 
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString(Config.blipsMap.wigShop.name)
            EndTextCommandSetBlipName(blip)
        end
    end
end)

-- Target Intermediaries & Context Menus with Quantity Support
function OpenWigShopMenu()
    if GetEntityModel(PlayerPedId()) ~= `mp_f_freemode_01` then
        local femaleOnlyString = Config.Strings and Config.Strings.sell_female_only or "Only female personas can interact with this product line."
        Notification({ description = femaleOnlyString, type = 'error' })
        return
    end

    local options = {}
    local formatString = Config.Strings and Config.Strings.shop_item_price or "Price: $%d"
    local titleString = Config.Strings and Config.Strings.shop_browse or "Browse Shop"

    for _, item in ipairs(Config.shopItems) do
        table.insert(options, {
            title = item.label,
            description = string.format(formatString, item.price),
            event = '4kwigs:client:promptQuantity',
            args = { item = item.name, price = item.price, label = item.label }
        })
    end
    lib.registerContext({ id = 'wig_shop_menu', title = titleString, options = options })
    lib.showContext('wig_shop_menu')
end

-- Input Dialogue Prompt Engine for Selectable Quantities
RegisterNetEvent('4kwigs:client:promptQuantity', function(data)
    local input = lib.inputDialog('Specify Quantity', {
        {
            type = 'number', 
            label = string.format('How many %s units would you like to buy?', data.label), 
            description = string.format('Cost per unit: $%d', data.price), 
            default = 1, 
            min = 1, 
            max = 100, 
            required = true
        }
    })

    if not input or not input[1] then 
        OpenWigShopMenu() 
        return 
    end
    
    local quantity = math.floor(tonumber(input[1]))
    if quantity > 0 then
        TriggerServerEvent('4kwigs:server:processPurchase', data, quantity)
    end
end)

-- Crafting Processing Setup
function OpenCraftingStation()
    local options = {}
    for _, wig in ipairs(Config.wigTypes) do
        local reqTxt = ""
        for _, req in ipairs(wig.requirements) do
            reqTxt = reqTxt .. string.format("\n- %d x %s", req.amount, req.item)
        end
        table.insert(options, {
            title = wig.name,
            description = "Requires:" .. reqTxt,
            event = '4kwigs:client:promptCraftQuantity',
            args = { craftData = wig }
        })
    end
    lib.registerContext({ id = 'wig_craft_menu', title = 'Crafting Station', options = options })
    lib.showContext('wig_craft_menu')
end

-- Input Dialogue Prompt Engine for Selectable Crafting Quantities
RegisterNetEvent('4kwigs:client:promptCraftQuantity', function(data)
    local baseTime = data.craftData.time or 5

    local input = lib.inputDialog('Crafting Options', {
        {
            type = 'number', 
            label = string.format('How many %s units would you like to craft?', data.craftData.name), 
            description = string.format('Time factor: %d seconds per individual item layout.', baseTime),
            default = 1, 
            min = 1, 
            max = 50, 
            required = true
        }
    })

    if not input or not input[1] then 
        OpenCraftingStation() 
        return 
    end
    
    local quantity = math.floor(tonumber(input[1]))
    if quantity > 0 then
        local calculatedTotalSeconds = baseTime * quantity
        
        Notification({ 
            description = string.format("Batch Order: Processing %dx items will require %d seconds total.", quantity, calculatedTotalSeconds), 
            type = 'info',
            duration = 5000
        })

        TriggerServerEvent('4kwigs:server:attemptCraft', data.craftData, quantity)
    end
end)

RegisterNetEvent('4kwigs:client:startCraftingProg', function(craftData, quantity)
    local progressLabel = Config.Strings and Config.Strings.craft_progress or "Crafting wigs..."
    local totalDuration = (craftData.time * 1000) * quantity

    if lib.progressCircle({
        label = string.format("%s (%dx) - Expected: %ds", progressLabel, quantity, (craftData.time * quantity)),
        duration = totalDuration,
        position = 'bottom',
        useWhileDead = false,
        canCancel = true,
        disable = { car = true, move = true, combat = true },
        anim = { dict = 'mini@repair', clip = 'fixing_a_ped' }
    }) then
        TriggerServerEvent('4kwigs:server:giveCraftReward', craftData, quantity)
    end
end)

-- Cleanup Hand Prop
local function removeHandProp()
    if holdingBag and DoesEntityExist(holdingBag) then
        DeleteEntity(holdingBag)
        holdingBag = nil
    end
end

-- Create & Attach Shopping Bag Prop Completely Upright & Leg-Aligned for Females
local function createHandProp()
    removeHandProp()
    local playerPed = PlayerPedId()
    local propHash = `prop_shopping_bags01`
    
    RequestModel(propHash)
    while not HasModelLoaded(propHash) do Wait(10) end
    
    local coords = GetEntityCoords(playerPed)
    holdingBag = CreateObject(propHash, coords.x, coords.y, coords.z, true, true, false)
    
    AttachEntityToEntity(holdingBag, playerPed, GetPedBoneIndex(playerPed, 57005), 0.15, 0.05, -0.02, -120.0, 15.0, 15.0, true, true, false, true, 1, true)
    SetModelAsNoLongerNeeded(propHash)
end

-- Cleanly removes the spawned customer ped from game memory
local function clearCurrentCustomer()
    if currentCustomerPed and DoesEntityExist(currentCustomerPed) then
        SetEntityAsNoLongerNeeded(currentCustomerPed)
        TaskWanderStandard(currentCustomerPed, 10.0, 10)
        currentCustomerPed = nil
    end
end

-- Core Function to Automatically Generate Next Customer
local function SpawnNextCustomer()
    if not isSellingActive then return end
    
    clearCurrentCustomer()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    
    local modelSelected = randomPedModels[math.random(1, #randomPedModels)]
    RequestModel(modelSelected)
    while not HasModelLoaded(modelSelected) do Wait(10) end
    
    local playerHeadingRad = math.rad(GetEntityHeading(playerPed))
    local spawnX = playerCoords.x - (math.sin(playerHeadingRad) * 12.0) + math.random(-3, 3)
    local spawnY = playerCoords.y - (math.cos(playerHeadingRad) * 12.0) + math.random(-3, 3)
    local _, spawnZ = GetGroundZFor_3dCoord(spawnX, spawnY, playerCoords.z + 10.0, tonumber(0))
    
    currentCustomerPed = CreatePed(4, modelSelected, spawnX, spawnY, spawnZ or playerCoords.z, math.random(0, 360), true, false)
    
    SetEntityAsMissionEntity(currentCustomerPed, true, true)
    SetBlockingOfNonTemporaryEvents(currentCustomerPed, true)
    SetModelAsNoLongerNeeded(modelSelected)
    
    TriggerServerEvent('4kwigs:server:initiatePocketSell', NetworkGetNetworkIdFromEntity(currentCustomerPed))
end

-- /sellwigs Command Engine
RegisterCommand(Config.sellWigs.command, function()
    local playerPed = PlayerPedId()
    
    if GetEntityModel(playerPed) ~= `mp_f_freemode_01` then
        local femaleOnlyString = Config.Strings and Config.Strings.sell_female_only or "Only female personas can interact with this product line."
        Notification({ description = femaleOnlyString, type = 'error' })
        return
    end

    if isSellingActive then
        isSellingActive = false
        clearCurrentCustomer()
        removeHandProp()
        Notification({ description = "You have stopped showcasing your items. Ped generation closed.", type = 'error' })
        return
    end

    isSellingActive = true
    SpawnNextCustomer()
end, false)

RegisterNetEvent('4kwigs:client:approachPlayer', function(targetWig, reward, targetNetId)
    local targetPed = NetworkGetEntityFromNetworkId(targetNetId)
    if not DoesEntityExist(targetPed) or not isSellingActive then return end

    createHandProp()
    Notification({ description = "An interested customer spawned nearby and is walking over!", type = 'info' })

    local playerPed = PlayerPedId()
    ClearPedTasks(targetPed)
    TaskGoToEntity(targetPed, playerPed, -1, 1.5, 1.2, 1056964608, 0)

    CreateThread(function()
        local maxWaitTime = 20000 
        local arrived = false

        while maxWaitTime > 0 and DoesEntityExist(targetPed) and not arrived and isSellingActive do
            Wait(500)
            maxWaitTime = maxWaitTime - 500
            
            local pCoords = GetEntityCoords(PlayerPedId())
            local tCoords = GetEntityCoords(targetPed)
            if #(pCoords - tCoords) <= 2.0 then
                arrived = true
            end
        end

        if arrived and isSellingActive then
            TriggerEvent('4kwigs:client:executeBargainSequence', targetWig, reward, targetNetId)
        else
            removeHandProp()
            clearCurrentCustomer()
            if isSellingActive then
                Notification({ description = "Customer pathing failed or took too long. Spawning next customer...", type = 'error' })
                Wait(3000)
                SpawnNextCustomer() 
            end
        end
    end)
end)

RegisterNetEvent('4kwigs:client:executeBargainSequence', function(targetWig, reward, targetNetId)
    local targetPed = NetworkGetEntityFromNetworkId(targetNetId)
    if not DoesEntityExist(targetPed) or not isSellingActive then removeHandProp() return end
    
    TaskTurnPedToFaceEntity(targetPed, PlayerPedId(), 1500)
    Wait(500)
    TaskStartScenarioInPlace(targetPed, "WORLD_HUMAN_STAND_IMPATIENT", 0, true)

    local success = lib.progressCircle({
        label = "Negotiating Transaction...",
        duration = Config.sellWigs.bargainTime,
        position = 'bottom',
        canCancel = true,
        disable = { move = true, mouse = false },
        anim = { dict = 'mp_common', clip = 'givetake2_a' }
    })

    ClearPedTasks(targetPed)
    removeHandProp() 

    if success then
        if math.random(1, 100) > Config.sellWigs.rejectRate then
            TriggerServerEvent('4kwigs:server:finalizePocketSale', targetWig, reward)
            TaskWanderStandard(targetPed, 10.0, 10)
        else
            local rejectedString = Config.Strings and Config.Strings.sell_rejected or "Buyer rejected your offer."
            Notification({ description = rejectedString, type = 'error' })
            TaskPlayAnim(targetPed, "gestures@f@standing@casual", "gesture_no_way", 8.0, -8.0, -1, 0, 0, false, false, false)
            Wait(3000)
        end
    else
        ClearPedTasks(PlayerPedId())
    end

    if isSellingActive then
        clearCurrentCustomer()
        Wait(4000) 
        SpawnNextCustomer()
    end
end)

-- Wearable Uniformity Trigger System
RegisterNetEvent('4kwigs:client:applyHairstyle', function(wigItem)
    local playerPed = PlayerPedId()
    if GetEntityModel(playerPed) ~= `mp_f_freemode_01` then
        local femaleOnlyString = Config.Strings and Config.Strings.sell_female_only or "Only female personas can interact with this product line."
        Notification({ description = femaleOnlyString, type = 'error' })
        return
    end

    local style = Config.wigAppearance.wigStyles[wigItem]
    if style then
        SetPedComponentVariation(playerPed, 2, style.hair, 0, style.color)
        Notification({ description = "Your pristine wig unit has been installed securely.", type = 'success' })
    end
end)

-- FIXED: Dynamic Crafting Table Placement with Precision Ground Height Adjustment Logic
RegisterNetEvent('4kwigs:client:placeTable', function()
    local playerPed = PlayerPedId()
    
    if isHoldingTable then return end
    isHoldingTable = true

    local modelHash = `prop_ven_market_table1`
    
    RequestModel(modelHash)
    local timeout = 0
    while not HasModelLoaded(modelHash) and timeout < 200 do
        Wait(10)
        timeout = timeout + 1
    end

    if not HasModelLoaded(modelHash) then
        isHoldingTable = false
        Notification({ description = "Failed to load table model stream.", type = 'error' })
        return
    end

    local currentHeading = GetEntityHeading(playerPed)
    local currentHeightOffset = -0.4 
    local forwardDistance = 1.5

    local playerCoords = GetEntityCoords(playerPed)
    local previewProp = CreateObject(modelHash, playerCoords.x, playerCoords.y, playerCoords.z, false, true, false)
    SetEntityAlpha(previewProp, 150, false) 
    SetEntityCollision(previewProp, false, false)

    Notification({ 
        description = "[E] Place | [X] Cancel\n[← / →] Rotate | [PgUp / PgDn] Raise/Lower", 
        type = 'info', 
        duration = 10000 
    })

    CreateThread(function()
        while isHoldingTable do
            Wait(0)
            
            DisableControlAction(0, 38, true)  -- E
            DisableControlAction(0, 73, true)  -- X
            DisableControlAction(0, 174, true) -- Arrow Left
            DisableControlAction(0, 175, true) -- Arrow Right
            DisableControlAction(0, 10, true)  -- Page Up
            DisableControlAction(0, 11, true)  -- Page Down

            local headingRad = math.rad(GetEntityHeading(playerPed))
            local baseCoords = GetEntityCoords(playerPed)
            local targetX = baseCoords.x + (math.sin(-headingRad) * forwardDistance)
            local targetY = baseCoords.y + (math.cos(-headingRad) * forwardDistance)
            local targetZ = baseCoords.z + currentHeightOffset

            SetEntityCoords(previewProp, targetX, targetY, targetZ, false, false, false, false)
            SetEntityHeading(previewProp, currentHeading)

            if IsDisabledControlPressed(0, 174) then
                currentHeading = (currentHeading + 2.0) % 360.0
            elseif IsDisabledControlPressed(0, 175) then
                currentHeading = (currentHeading - 2.0) % 360.0
            end

            if IsDisabledControlPressed(0, 10) then
                currentHeightOffset = math.min(currentHeightOffset + 0.02, 1.5)
            elseif IsDisabledControlPressed(0, 11) then
                currentHeightOffset = math.max(currentHeightOffset - 0.02, -1.5)
            end

            if IsDisabledControlJustPressed(0, 38) then
                isHoldingTable = false
                local finalCoords = GetEntityCoords(previewProp)
                local finalHeading = GetEntityHeading(previewProp)
                
                DeleteEntity(previewProp)

                -- GROUND RAYCAST HEIGHT CORRECTION ENGINE:
                -- Queries world physics to snap the final vector directly to ground height
                local _, groundZ = GetGroundZFor_3dCoord(finalCoords.x, finalCoords.y, finalCoords.z + 2.0, tonumber(0))
                if groundZ and groundZ ~= 0 then
                    finalCoords = vector3(finalCoords.x, finalCoords.y, groundZ)
                end
                
                TriggerServerEvent('4kwigs:server:confirmPlacement', finalCoords, finalHeading)
            end

            if IsDisabledControlJustPressed(0, 73) then
                isHoldingTable = false
                DeleteEntity(previewProp)
                Notification({ description = "Placement cancelled.", type = 'error' })
            end
        end
    end)
end)

-- Universal targets mapped straight to model definitions
CreateThread(function()
    exports.ox_target:addModel(`prop_ven_market_table1`, {
        {
            name = 'open_wig_crafting_global',
            icon = 'fa-solid fa-scissors',
            label = 'Craft Wigs',
            onSelect = function() 
                OpenCraftingStation() 
            end
        },
        {
            name = 'pickup_wig_crafting_table',
            icon = 'fa-solid fa-hand-holding',
            label = 'Pack up Table',
            onSelect = function(data)
                local entity = data.entity
                if DoesEntityExist(entity) then
                    local netId = NetworkGetNetworkIdFromEntity(entity)
                    TriggerServerEvent('4kwigs:server:pickupTable', netId)
                end
            end
        }
    })
end)

-- Ox Target Supplier BoxZone Coordinate Mapping
CreateThread(function()
    exports.ox_target:addBoxZone({
        coords = vec3(Config.shopPed.coords.x, Config.shopPed.coords.y, Config.shopPed.coords.z - 1.0),
        size = vec3(1.5, 1.5, 2.5),
        rotation = Config.shopPed.coords.w,
        options = {
            {
                name = 'open_wig_shop',
                icon = 'fa-solid fa-store',
                label = 'Interact with Supplier',
                onSelect = function() OpenWigShopMenu() end
            }
        }
    })
end)