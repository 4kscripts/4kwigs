function Notification(data)
    if Config.Notification == 'ox_lib' then
        lib.notify({
            title = data.title or Config.Strings.notification_title,
            description = data.description,
            type = data.type or 'info',
            duration = data.duration or 5000
        })
    elseif Config.Notification == 'qb' then
        exports['qb-core']:GetCoreObject().Functions.Notify(data.description, data.type, data.duration)
    elseif Config.Notification == 'esx' then
        exports["es_extended"]:getSharedObject().ShowNotification(data.description, data.type, data.duration)
    end
end

function giveKeys(vehicle)
    local plate = GetVehicleNumberPlateText(vehicle)
    local script = Config.DeliverySystem.givekeyScript
    if script == 'qb' then
        TriggerEvent('vehiclekeys:client:SetOwner', plate)
    elseif script ~= '' then
        pcall(function() exports[script]:GiveKey(plate) end)
    end
end